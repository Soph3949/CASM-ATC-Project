// Head-on collision avoidance: two Crazyflie 2.1 Brushless quadcopters.
// Units are metres and seconds unless noted; the drone model is built in millimetres.
(() => {
  'use strict';

  const css = getComputedStyle(document.documentElement);
  const tok = name => css.getPropertyValue(name).trim();
  const COL = {
    a: tok('--a'), b: tok('--b'), alert: tok('--alert'), ok: tok('--ok'),
    text: tok('--text'), muted: tok('--muted'), rule: tok('--rule'),
  };
  const V3 = THREE.Vector3;
  if (THREE.ColorManagement) THREE.ColorManagement.legacyMode = false;   // hex colours are sRGB
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const $ = id => document.getElementById(id);

  // ---------- parameters ----------
  const P = {
    approach: 0.4,     // m/s, each drone
    vVert: 0.5,        // m/s, max climb / descent rate
    offset: 0.25,      // m, altitude change during avoidance
    trigger: 0.30,     // m, centre-to-centre distance that starts avoidance
    simSpeed: 1,
    cruise: 1.0,       // m
    startX: 1.5,       // m, each drone starts this far from the centre
    returnAlt: true, loop: true, trails: true, zone: true,
  };
  const CLEARANCE = 0.155;           // m: 100 mm frame + 55 mm propeller
  const TAU = 0.12;                  // s, velocity response lag
  const KP_ALT = 4, KP_X = 2;        // position gains
  const H = 1 / 240;                 // s, simulation step

  function makeRenderer(container) {
    const r = new THREE.WebGLRenderer({ antialias: true });
    r.setPixelRatio(Math.min(devicePixelRatio, 2));
    r.outputEncoding = THREE.sRGBEncoding;
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.toneMappingExposure = 1.0;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    container.prepend(r.domElement);
    return r;
  }
  // Let the page scroll normally over a 3D view; wheel-zoom only after the view is clicked.
  function zoomOnClick(controls, box) {
    controls.enableZoom = false;
    box.addEventListener('pointerdown', () => { controls.enableZoom = true; });
    box.addEventListener('pointerleave', () => { controls.enableZoom = false; });
  }
  function addEnvironment(renderer, scene) {
    if (!THREE.RoomEnvironment) return;
    const pm = new THREE.PMREMGenerator(renderer);
    scene.environment = pm.fromScene(new THREE.RoomEnvironment(), 0.04).texture;
  }

  // =====================================================================
  // Crazyflie 2.1 Brushless model
  // =====================================================================
  const glowTex = (() => {
    const c = document.createElement('canvas'); c.width = c.height = 64;
    const g = c.getContext('2d');
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.25, 'rgba(255,255,255,.5)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  })();

  // one propeller blade, 55 mm prop => 27.5 mm radius
  function makeBladeGeometry() {
    const s = new THREE.Shape();
    s.moveTo(2, -2.1);
    s.bezierCurveTo(9, -3.7, 19, -3.6, 26.2, -1.4);
    s.quadraticCurveTo(28.2, -0.2, 26.8, 1.3);
    s.bezierCurveTo(19, 3.1, 9, 3.4, 2, 2.1);
    s.lineTo(2, -2.1);
    const g = new THREE.ExtrudeGeometry(s, { depth: 0.55, bevelEnabled: false, curveSegments: 10 });
    g.translate(0, 0, -0.275);
    g.rotateX(-Math.PI / 2);
    return g;
  }

  function buildCrazyflie(labelColor) {
    const bladeGeo = makeBladeGeometry();
    const discGeo = new THREE.CircleGeometry(27.5, 48).rotateX(-Math.PI / 2);
    const pinGeo = new THREE.BoxGeometry(0.64, 2.4, 0.64);

    const root = new THREE.Group();                 // metres
    const m = new THREE.Group();                    // millimetres
    m.scale.setScalar(0.001);
    root.add(m);

    const mat = {
      pcb: new THREE.MeshStandardMaterial({ color: 0x16191d, roughness: 0.42, metalness: 0.15 }),
      gold: new THREE.MeshStandardMaterial({ color: 0xc8a24a, roughness: 0.3, metalness: 0.9 }),
      plastic: new THREE.MeshStandardMaterial({ color: 0x2c3036, roughness: 0.75 }),
      stator: new THREE.MeshStandardMaterial({ color: 0x202226, roughness: 0.45, metalness: 0.6 }),
      bell: new THREE.MeshStandardMaterial({ color: 0x8d939b, roughness: 0.28, metalness: 0.9 }),
      prop: new THREE.MeshStandardMaterial({ color: 0x1b1d21, roughness: 0.45, side: THREE.DoubleSide }),
      chip: new THREE.MeshStandardMaterial({ color: 0x2b2e33, roughness: 0.6, metalness: 0.1 }),
      battery: new THREE.MeshStandardMaterial({ color: 0xaab3bd, roughness: 0.35, metalness: 0.55 }),
      label: new THREE.MeshStandardMaterial({ color: labelColor, roughness: 0.6 }),
      header: new THREE.MeshStandardMaterial({ color: 0x0f1012, roughness: 0.7 }),
      red: new THREE.MeshStandardMaterial({ color: 0xb3261e, roughness: 0.5 }),
      black: new THREE.MeshStandardMaterial({ color: 0x0d0d0e, roughness: 0.5 }),
      white: new THREE.MeshStandardMaterial({ color: 0xd9d6cf, roughness: 0.6 }),
    };
    const add = (geo, material, x = 0, y = 0, z = 0, parent = m) => {
      const o = new THREE.Mesh(geo, material);
      o.position.set(x, y, z);
      parent.add(o);
      return o;
    };
    const T = 1.6;   // PCB thickness

    // centre plate: rounded square
    const s = new THREE.Shape(), h = 16, r = 4;
    s.moveTo(-h + r, -h); s.lineTo(h - r, -h); s.quadraticCurveTo(h, -h, h, -h + r);
    s.lineTo(h, h - r); s.quadraticCurveTo(h, h, h - r, h); s.lineTo(-h + r, h);
    s.quadraticCurveTo(-h, h, -h, h - r); s.lineTo(-h, -h + r); s.quadraticCurveTo(-h, -h, -h + r, -h);
    const plate = new THREE.ExtrudeGeometry(s, { depth: T, bevelEnabled: false, curveSegments: 6 });
    plate.rotateX(-Math.PI / 2);
    add(plate, mat.pcb);

    // X layout, forward = +x, right = +z. M1 front-right, M2 rear-right, M3 rear-left, M4 front-left.
    const R = 50;   // centre to motor: 100 mm diagonal
    const motors = [
      { a: Math.PI / 4,      spin: +1, led: 0x30d158 },
      { a: 3 * Math.PI / 4,  spin: -1, led: 0x2f7bff },
      { a: -3 * Math.PI / 4, spin: +1, led: 0x2f7bff },
      { a: -Math.PI / 4,     spin: -1, led: 0xff3b30 },
    ];
    const props = [];
    motors.forEach(mo => {
      const c = Math.cos(mo.a), sn = Math.sin(mo.a);
      const cx = R * c, cz = R * sn;

      const arm = add(new THREE.BoxGeometry(40, T, 7.5), mat.pcb, 30 * c, T / 2, 30 * sn);
      arm.rotation.y = -mo.a;
      add(new THREE.CylinderGeometry(7.2, 7.2, T, 28), mat.pcb, cx, T / 2, cz);
      [-1.6, 0, 1.6].forEach(o => {                  // motor solder pads
        const p = add(new THREE.BoxGeometry(1.6, 0.08, 1.1), mat.gold, 41 * c - o * sn, T + 0.04, 41 * sn + o * c);
        p.rotation.y = -mo.a;
      });

      // motor clip and landing leg
      add(new THREE.CylinderGeometry(6.6, 6.2, 7, 28), mat.plastic, cx, -3.5, cz);
      add(new THREE.CylinderGeometry(5.0, 5.0, 1.2, 24), mat.stator, cx, -7.4, cz);
      const leg = add(new THREE.CylinderGeometry(1.1, 0.8, 13, 10), mat.plastic, cx + 1.4 * c, -13.8, cz + 1.4 * sn);
      leg.rotation.set(0.12 * sn, 0, -0.12 * c);
      add(new THREE.SphereGeometry(1.4, 12, 8), mat.plastic, cx + 2.2 * c, -20.2, cz + 2.2 * sn);

      // status LED
      const ledPos = new V3(23 * c, T + 0.45, 23 * sn);
      add(new THREE.BoxGeometry(1.6, 0.9, 1.2), new THREE.MeshBasicMaterial({ color: mo.led }), ledPos.x, ledPos.y, ledPos.z);
      const glow = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowTex, color: mo.led, blending: THREE.AdditiveBlending, depthWrite: false, transparent: true, opacity: 0.7,
      }));
      glow.position.set(ledPos.x, ledPos.y + 0.6, ledPos.z);
      glow.scale.set(9, 9, 1);
      m.add(glow);

      // rotor: motor bell, shaft, propeller
      const rotor = new THREE.Group();
      rotor.position.set(cx, T, cz);
      m.add(rotor);
      add(new THREE.CylinderGeometry(5.35, 5.35, 5.4, 28), mat.bell, 0, 2.7, 0, rotor);
      add(new THREE.CylinderGeometry(4.0, 5.35, 0.9, 28), mat.stator, 0, 5.85, 0, rotor);
      add(new THREE.CylinderGeometry(0.75, 0.75, 3, 8), mat.bell, 0, 7, 0, rotor);
      add(new THREE.CylinderGeometry(2.6, 2.6, 2.4, 18), mat.prop, 0, 7.9, 0, rotor);
      for (let k = 0; k < 2; k++) {
        const pivot = new THREE.Group();
        pivot.rotation.y = k * Math.PI;
        pivot.position.y = 7.9;
        rotor.add(pivot);
        const blade = new THREE.Mesh(bladeGeo, mat.prop);
        blade.rotation.x = 0.22 * mo.spin;           // blade pitch
        pivot.add(blade);
      }
      const disc = new THREE.Mesh(discGeo, new THREE.MeshBasicMaterial({
        color: 0x6d7782, transparent: true, opacity: 0.08, depthWrite: false, side: THREE.DoubleSide,
      }));
      disc.position.y = 8.1;
      disc.userData.noShadow = true;
      rotor.add(disc);
      props.push({ rotor, spin: mo.spin, disc });
    });

    // expansion-deck pin headers, 2 x 10 at 2.54 mm pitch
    [-10.5, 10.5].forEach(z => {
      add(new THREE.BoxGeometry(25.4, 2.5, 2.5), mat.header, 0, T + 1.25, z);
      for (let i = 0; i < 10; i++) add(pinGeo, mat.gold, -11.43 + i * 2.54, T + 3.7, z);
    });

    // battery holder, 350 mAh 1S LiPo, label, lead and connector
    add(new THREE.BoxGeometry(30, 1.2, 17), mat.plastic, 0, T + 0.6, 0);
    add(new THREE.BoxGeometry(29, 6, 16), mat.battery, 0, T + 4.2, 0);
    add(new THREE.BoxGeometry(20, 0.2, 12), mat.label, 1, T + 7.3, 0);
    [[1.1, mat.red], [-1.1, mat.black]].forEach(([z, material]) => {
      const wire = add(new THREE.CylinderGeometry(0.5, 0.5, 7, 6), material, -18, T + 3.5, z);
      wire.rotation.z = Math.PI / 2;
    });
    add(new THREE.BoxGeometry(3.5, 3, 5.5), mat.white, -22.5, T + 3.2, 0);

    // underside electronics
    add(new THREE.BoxGeometry(7, 1, 7), mat.chip, 3, -0.5, 0);
    add(new THREE.BoxGeometry(5, 0.9, 5), mat.chip, -8, -0.45, 5);
    add(new THREE.BoxGeometry(3, 0.8, 3), mat.chip, -7, -0.4, -6);
    for (let i = 0; i < 6; i++) add(new THREE.BoxGeometry(1, 0.5, 0.5), mat.chip, 10, -0.25, -6 + i * 2.4);
    add(new THREE.BoxGeometry(3, 1.4, 3), mat.white, -13, T + 0.7, -12.5);   // power button

    m.traverse(o => {
      if (o.isMesh && !o.userData.noShadow && o.material.type !== 'MeshBasicMaterial') o.castShadow = true;
    });
    return { root, props };
  }

  // =====================================================================
  // Main simulation scene
  // =====================================================================
  const viewer = $('viewer');
  const renderer = makeRenderer(viewer);
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(tok('--stage'));
  scene.fog = new THREE.Fog(scene.background.getHex(), 6, 14);
  addEnvironment(renderer, scene);

  const camera = new THREE.PerspectiveCamera(40, 16 / 9, 0.005, 60);
  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 0.08;
  controls.maxDistance = 12;
  controls.maxPolarAngle = Math.PI * 0.495;
  zoomOnClick(controls, viewer);

  scene.add(new THREE.HemisphereLight(0xffffff, 0x9aa3ad, 0.45));
  const sun = new THREE.DirectionalLight(0xffffff, 1.2);
  sun.position.set(2, 5, 3);
  sun.castShadow = true;
  Object.assign(sun.shadow.camera, { left: -2.6, right: 2.6, top: 2.6, bottom: -2.6, near: 1, far: 12 });
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.bias = -0.0003;
  scene.add(sun);

  const floor = new THREE.Mesh(new THREE.PlaneGeometry(16, 16),
    new THREE.MeshStandardMaterial({ color: 0xd3d8de, roughness: 1, metalness: 0, envMapIntensity: 0.2 }));
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  const fineGrid = new THREE.GridHelper(6, 60, 0xb4bcc5, 0xb4bcc5);
  fineGrid.material.transparent = true; fineGrid.material.opacity = 0.5; fineGrid.position.y = 0.001;
  scene.add(fineGrid);
  const majorGrid = new THREE.GridHelper(6, 6, 0x87919c, 0x87919c);
  majorGrid.position.y = 0.002;
  scene.add(majorGrid);

  const flightLine = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([new V3(-2.2, 0.003, 0), new V3(2.2, 0.003, 0)]),
    new THREE.LineDashedMaterial({ color: 0x6b7480, dashSize: 0.05, gapSize: 0.05 }));
  flightLine.computeLineDistances();
  scene.add(flightLine);
  [[-P.startX, COL.a], [P.startX, COL.b]].forEach(([x, color]) => {
    const pad = new THREE.Mesh(new THREE.RingGeometry(0.07, 0.085, 48),
      new THREE.MeshBasicMaterial({ color, side: THREE.DoubleSide }));
    pad.rotation.x = -Math.PI / 2;
    pad.position.set(x, 0.004, 0);
    scene.add(pad);
  });

  // ---------- drones ----------
  const drones = [
    { id: 'A', dir: +1, color: COL.a },
    { id: 'B', dir: -1, color: COL.b },
  ];
  const TRAIL_N = 3000;
  drones.forEach(d => {
    d.model = buildCrazyflie(new THREE.Color(d.color).getHex());
    scene.add(d.model.root);
    d.p = new V3(); d.v = new V3(); d.acc = new V3();
    d.targetY = P.cruise; d.tilt = 0;

    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.BufferAttribute(new Float32Array(TRAIL_N * 3), 3));
    d.trail = new THREE.Line(tg, new THREE.LineBasicMaterial({ color: d.color }));
    d.trail.frustumCulled = false;
    scene.add(d.trail);
    d.trailN = 0;

    d.drop = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(), new V3()]),
      new THREE.LineDashedMaterial({ color: d.color, dashSize: 0.025, gapSize: 0.025, transparent: true, opacity: 0.6 }));
    d.drop.frustumCulled = false;
    scene.add(d.drop);
    d.mark = new THREE.Mesh(new THREE.RingGeometry(0.03, 0.04, 32),
      new THREE.MeshBasicMaterial({ color: d.color, side: THREE.DoubleSide }));
    d.mark.rotation.x = -Math.PI / 2;
    scene.add(d.mark);

    d.tag = document.createElement('div');
    d.tag.className = 'tag';
    d.tag.style.borderLeftColor = d.color;
    $('tags').appendChild(d.tag);
  });
  const [A, B] = drones;

  const link = new THREE.Line(new THREE.BufferGeometry().setFromPoints([new V3(), new V3()]),
    new THREE.LineDashedMaterial({ color: COL.muted, dashSize: 0.02, gapSize: 0.015 }));
  link.frustumCulled = false;
  scene.add(link);
  const zone = new THREE.Mesh(new THREE.SphereGeometry(1, 24, 12),
    new THREE.MeshBasicMaterial({ color: COL.alert, wireframe: true, transparent: true, opacity: 0.1, depthWrite: false }));
  scene.add(zone);

  // =====================================================================
  // Simulation
  // =====================================================================
  const sim = {};
  let running = true;
  let plotsDirty = true;

  function reset() {
    Object.assign(sim, {
      t: 0, phase: 'approach', triggered: false, trigT: null, trigD: null,
      minD: Infinity, minT: 0, passed: false, returning: false, doneT: null,
      hist: [], histNext: 0, dist: 2 * P.startX,
    });
    drones.forEach(d => {
      d.p.set(-d.dir * P.startX, P.cruise, 0);
      d.v.set(0, 0, 0); d.acc.set(0, 0, 0);
      d.targetY = P.cruise; d.tilt = 0;
      d.trailN = 0; d.trail.geometry.setDrawRange(0, 0);
    });
    plotsDirty = true;
    updateResultText();
  }

  function step(h) {
    sim.t += h;
    for (const d of drones) {
      const endX = d.dir * P.startX;
      const vxCmd = clamp(KP_X * (endX - d.p.x), -P.approach, P.approach);
      const vyCmd = clamp(KP_ALT * (d.targetY - d.p.y), -P.vVert, P.vVert);
      d.acc.set((vxCmd - d.v.x) / TAU, (vyCmd - d.v.y) / TAU, 0);
      d.v.x += d.acc.x * h; d.v.y += d.acc.y * h;
      d.p.x += d.v.x * h;   d.p.y += d.v.y * h;
    }

    const dist = A.p.distanceTo(B.p);
    sim.dist = dist;

    // avoidance rule
    if (!sim.triggered && dist < P.trigger) {
      sim.triggered = true; sim.trigT = sim.t; sim.trigD = dist; sim.phase = 'avoid';
      A.targetY = P.cruise + P.offset;
      B.targetY = P.cruise - P.offset;
    }
    const dx = B.p.x - A.p.x;                       // positive until they cross
    if (sim.triggered && !sim.passed && dx < 0) sim.passed = true;
    if (sim.passed && !sim.returning && -dx > P.trigger) {
      sim.returning = true;
      if (P.returnAlt) { A.targetY = B.targetY = P.cruise; sim.phase = 'return'; }
      else sim.phase = 'clear';
      updateResultText();
    }

    if (dist < sim.minD) { sim.minD = dist; sim.minT = sim.t; }
    if (sim.phase !== 'done' && sim.returning && drones.every(d =>
        Math.abs(d.v.x) < 0.01 && Math.abs(d.v.y) < 0.01 && Math.abs(d.p.x - d.dir * P.startX) < 0.01)) {
      sim.phase = 'done'; sim.doneT = sim.t;
    }
    if (sim.t >= sim.histNext) {
      sim.hist.push([sim.t, dist, A.p.y, B.p.y]);
      sim.histNext += 1 / 30;
      plotsDirty = true;
    }
    if (sim.phase === 'done' && P.loop && sim.t - sim.doneT > 1.5) reset();
  }

  // =====================================================================
  // Visual updates
  // =====================================================================
  function pushTrail(d) {
    const arr = d.trail.geometry.attributes.position.array;
    if (d.trailN > 0) {
      const i = (d.trailN - 1) * 3;
      const ddx = arr[i] - d.p.x, ddy = arr[i + 1] - d.p.y;
      if (ddx * ddx + ddy * ddy < 0.004 * 0.004) return;
    }
    if (d.trailN >= TRAIL_N) { arr.copyWithin(0, 3); d.trailN = TRAIL_N - 1; }
    const j = d.trailN * 3;
    arr[j] = d.p.x; arr[j + 1] = d.p.y; arr[j + 2] = d.p.z;
    d.trailN++;
    d.trail.geometry.setDrawRange(0, d.trailN);
    d.trail.geometry.attributes.position.needsUpdate = true;
  }

  function updateScene(dt) {
    for (const d of drones) {
      const r = d.model.root;
      r.position.copy(d.p);
      // pitch the nose down in proportion to forward speed and acceleration
      const vf = d.v.x * d.dir, af = d.acc.x * d.dir;
      const tilt = -clamp(0.32 * vf + 0.035 * af, -0.45, 0.45);
      d.tilt += (tilt - d.tilt) * Math.min(1, dt * 12);
      r.rotation.set(0, d.dir > 0 ? 0 : Math.PI, d.tilt);

      d.model.props.forEach(pr => {
        pr.disc.visible = running;
        if (running) pr.rotor.rotation.y += pr.spin * (62 + 14 * clamp(d.acc.y, -3, 3) / 3) * dt * P.simSpeed;
      });

      pushTrail(d);
      d.trail.visible = P.trails;
      const dp = d.drop.geometry.attributes.position;
      dp.setXYZ(0, d.p.x, d.p.y - 0.022, d.p.z);
      dp.setXYZ(1, d.p.x, 0.005, d.p.z);
      dp.needsUpdate = true;
      d.drop.computeLineDistances();
      d.mark.position.set(d.p.x, 0.005, d.p.z);
    }
    const lp = link.geometry.attributes.position;
    lp.setXYZ(0, A.p.x, A.p.y, A.p.z);
    lp.setXYZ(1, B.p.x, B.p.y, B.p.z);
    lp.needsUpdate = true;
    link.computeLineDistances();
    link.material.color.set(sim.dist < P.trigger ? COL.alert : COL.muted);

    zone.visible = P.zone;
    zone.position.copy(A.p);
    zone.scale.setScalar(P.trigger);
    zone.material.opacity = sim.triggered && !sim.passed ? 0.25 : 0.1;
  }

  // ---------- camera views ----------
  const VIEWS = {
    overview: { follow: false, target: () => new V3(0, P.cruise * 0.9, 0), offset: () => new V3(1.3, 0.7, 2.0).multiplyScalar(aspectScale()) },
    side:     { follow: false, target: () => new V3(0, P.cruise, 0),       offset: () => new V3(0, 0.08, 2.9).multiplyScalar(aspectScale()) },
    follow:   { follow: true,  target: () => A.p.clone().add(B.p).multiplyScalar(0.5), offset: () => new V3(0.3, 0.16, 1.25).multiplyScalar(aspectScale()) },
    closeup:  { follow: true,  target: () => A.p.clone(), offset: () => new V3(0.15, 0.085, 0.19) },
  };
  let view = 'overview';
  let tween = null;
  function aspectScale() { return camera.aspect < 1.4 ? Math.min(2.2, 1.4 / camera.aspect) : 1; }
  function setView(name, instant) {
    view = name;
    const v = VIEWS[name];
    if (instant) {
      const tgt = v.target();
      controls.target.copy(tgt);
      camera.position.copy(tgt).add(v.offset());
      tween = null;
      return;
    }
    tween = { t: 0, fromPos: camera.position.clone(), fromTgt: controls.target.clone(), offset: v.offset() };
    controls.enabled = false;
  }
  function updateCamera(dt) {
    const v = VIEWS[view];
    if (tween) {
      tween.t = Math.min(1, tween.t + dt / 0.9);
      const e = tween.t < 0.5 ? 4 * tween.t ** 3 : 1 - (-2 * tween.t + 2) ** 3 / 2;
      const tgt = v.target();
      controls.target.lerpVectors(tween.fromTgt, tgt, e);
      camera.position.lerpVectors(tween.fromPos, tgt.clone().add(tween.offset), e);
      if (tween.t >= 1) { tween = null; controls.enabled = true; }
    } else if (v.follow) {
      const tgt = v.target();
      camera.position.add(tgt.clone().sub(controls.target));
      controls.target.copy(tgt);
    }
    controls.update();
  }

  // ---------- labels above the drones ----------
  const proj = new V3();
  function updateTags() {
    const w = viewer.clientWidth, h = viewer.clientHeight;
    for (const d of drones) {
      proj.copy(d.p); proj.y += 0.045; proj.project(camera);
      if (proj.z > 1 || view === 'closeup') { d.tag.hidden = true; continue; }
      d.tag.hidden = false;
      d.tag.style.transform =
        `translate(${((proj.x + 1) / 2 * w).toFixed(1)}px, ${((1 - proj.y) / 2 * h).toFixed(1)}px) translate(-50%, -100%)`;
      d.tag.textContent = `${d.id} · ${d.p.y.toFixed(2)} m`;
    }
  }

  // =====================================================================
  // Readouts and results text
  // =====================================================================
  const STATUS = {
    approach: 'Approaching', avoid: 'Avoiding', return: 'Returning to 1.0 m', clear: 'Passed', done: 'Complete',
  };
  const m3 = v => `${v.toFixed(3)} m`;
  const signed = v => `${v >= 0 ? '+' : '−'}${Math.abs(v).toFixed(2)} m/s`;

  function updateReadout() {
    $('r-time').textContent = `${sim.t.toFixed(2)} s`;
    const st = $('r-status');
    st.textContent = STATUS[sim.phase];
    st.className = sim.phase === 'avoid' ? 'status-avoid' : '';
    $('r-dist').textContent = m3(sim.dist);
    $('r-dist').className = sim.dist < P.trigger ? 'bad' : '';
    $('r-dx').textContent = m3(Math.abs(B.p.x - A.p.x));
    $('r-dy').textContent = m3(Math.abs(A.p.y - B.p.y));
    const mn = $('r-min');
    if (sim.passed) {
      mn.textContent = m3(sim.minD);
      mn.className = sim.minD > CLEARANCE ? 'good' : 'bad';
    } else { mn.textContent = '–'; mn.className = ''; }
    for (const d of drones) {
      const k = d.id.toLowerCase();
      $(k + '-alt').textContent = m3(d.p.y);
      $(k + '-vx').textContent = signed(d.v.x * d.dir);
      $(k + '-vz').textContent = signed(d.v.y);
    }
  }

  function updateResultText() {
    const el = $('result-text');
    if (!sim.returning) {
      el.textContent = 'The summary appears here once the drones have passed each other.';
      return;
    }
    const margin = (sim.minD - CLEARANCE) * 1000;
    const verdict = margin > 0
      ? `${margin.toFixed(0)} mm more than the 0.155 m safety clearance, so the drones pass without touching.`
      : `${Math.abs(margin).toFixed(0)} mm inside the 0.155 m safety clearance, so the propellers could touch. Try a lower approach speed or a higher climb rate.`;
    el.textContent =
      `With an approach speed of ${P.approach.toFixed(2)} m/s per drone and a ${P.trigger.toFixed(2)} m trigger, ` +
      `avoidance started at ${sim.trigD.toFixed(3)} m (t = ${sim.trigT.toFixed(2)} s). ` +
      `The closest approach was ${sim.minD.toFixed(3)} m at t = ${sim.minT.toFixed(2)} s, which is ${verdict}`;
  }

  // =====================================================================
  // Plots
  // =====================================================================
  function drawPlot(cv, cfg) {
    const dpr = Math.min(devicePixelRatio, 2), w = cv.clientWidth, h = cv.clientHeight;
    if (!w || !h) return;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
      cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
    }
    const ctx = cv.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);
    const L = 52, R = 16, T = 10, Bm = 34, pw = w - L - R, ph = h - T - Bm;
    const X = t => L + (t / cfg.xMax) * pw;
    const Y = v => T + (1 - (v - cfg.yMin) / (cfg.yMax - cfg.yMin)) * ph;
    ctx.font = `12px ${tok('--sans')}`;
    ctx.lineWidth = 1;

    // y grid + labels
    ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    cfg.yTicks.forEach(v => {
      const y = Math.round(Y(v)) + 0.5;
      ctx.strokeStyle = COL.rule;
      ctx.beginPath(); ctx.moveTo(L, y); ctx.lineTo(L + pw, y); ctx.stroke();
      ctx.fillStyle = COL.muted;
      ctx.fillText(v.toFixed(2), L - 6, Y(v));
    });
    // x axis
    ctx.strokeStyle = COL.text;
    ctx.beginPath(); ctx.moveTo(L, T + ph + 0.5); ctx.lineTo(L + pw, T + ph + 0.5); ctx.stroke();
    ctx.textAlign = 'center'; ctx.textBaseline = 'top'; ctx.fillStyle = COL.muted;
    const xStep = cfg.xMax > 12 ? 4 : 2;
    for (let t = 0; t <= cfg.xMax + 1e-6; t += xStep) ctx.fillText(String(t), X(t), T + ph + 5);
    ctx.fillText('time (s)', L + pw / 2, T + ph + 19);
    // y axis title
    ctx.save();
    ctx.translate(12, T + ph / 2); ctx.rotate(-Math.PI / 2);
    ctx.textBaseline = 'middle'; ctx.fillText(cfg.yLabel, 0, 0);
    ctx.restore();

    // reference lines
    (cfg.hlines || []).forEach(l => {
      ctx.save();
      ctx.strokeStyle = l.color; ctx.setLineDash(l.dash);
      ctx.beginPath(); ctx.moveTo(L, Y(l.y)); ctx.lineTo(L + pw, Y(l.y)); ctx.stroke();
      ctx.restore();
      ctx.fillStyle = l.color;
      ctx.textAlign = 'right'; ctx.textBaseline = l.below ? 'top' : 'bottom';
      ctx.fillText(l.label, L + pw - 2, l.below ? Y(l.y) + 3 : Y(l.y) - 3);
    });

    ctx.save();
    ctx.beginPath(); ctx.rect(L, T, pw, ph); ctx.clip();
    if (sim.trigT != null) {
      ctx.strokeStyle = COL.alert; ctx.setLineDash([2, 3]);
      ctx.beginPath(); ctx.moveTo(X(sim.trigT), T); ctx.lineTo(X(sim.trigT), T + ph); ctx.stroke();
      ctx.setLineDash([]);
    }
    cfg.series.forEach(s => {
      ctx.strokeStyle = s.color; ctx.lineWidth = 2;
      ctx.beginPath();
      sim.hist.forEach((row, i) => {
        const x = X(row[0]), y = Y(row[s.col]);
        if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y);
      });
      ctx.stroke();
    });
    if (cfg.marker) cfg.marker(ctx, X, Y);
    ctx.restore();
  }

  function drawPlots() {
    const xMax = Math.max(Math.ceil((2 * P.startX) / P.approach + 2.5), Math.ceil(sim.t));
    drawPlot($('plot-dist'), {
      xMax, yMin: 0, yMax: 1, yTicks: [0, 0.25, 0.5, 0.75, 1], yLabel: 'distance (m)',
      hlines: [
        { y: P.trigger, color: COL.alert, dash: [5, 4], label: `trigger ${P.trigger.toFixed(2)} m` },
        { y: CLEARANCE, color: COL.muted, dash: [1, 3], label: `clearance ${CLEARANCE} m`, below: true },
      ],
      series: [{ col: 1, color: COL.text }],
      marker: (ctx, X, Y) => {
        if (!sim.passed) return;
        ctx.strokeStyle = sim.minD > CLEARANCE ? COL.ok : COL.alert;
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(X(sim.minT), Y(sim.minD), 5, 0, Math.PI * 2); ctx.stroke();
      },
    });
    const c = P.cruise, o = P.offset;
    drawPlot($('plot-alt'), {
      xMax, yMin: c - o - 0.08, yMax: c + o + 0.08, yTicks: [c - o, c, c + o], yLabel: 'altitude (m)',
      series: [{ col: 2, color: COL.a }, { col: 3, color: COL.b }],
    });
  }

  // =====================================================================
  // Controls
  // =====================================================================
  function bindRange(id, key, format) {
    const el = $(id), out = $('o-' + id);
    const sync = () => { P[key] = parseFloat(el.value); out.textContent = format(P[key]); };
    el.addEventListener('input', () => { sync(); reset(); });
    sync();
  }
  bindRange('trigger', 'trigger', v => `${v.toFixed(2)} m`);
  bindRange('approach', 'approach', v => `${v.toFixed(2)} m/s`);
  bindRange('vvert', 'vVert', v => `${v.toFixed(2)} m/s`);
  bindRange('offset', 'offset', v => `±${v.toFixed(2)} m`);

  function bindCheck(id, key) {
    const el = $(id);
    P[key] = el.checked;
    el.addEventListener('change', () => { P[key] = el.checked; });
  }
  bindCheck('ret', 'returnAlt');
  bindCheck('loop', 'loop');
  bindCheck('trails', 'trails');
  bindCheck('zone', 'zone');

  const playBtn = $('play');
  function setRunning(r) { running = r; playBtn.textContent = r ? 'Pause' : 'Play'; }
  playBtn.addEventListener('click', () => {
    if (!running && sim.phase === 'done') reset();
    setRunning(!running);
  });
  $('restart').addEventListener('click', () => { reset(); setRunning(true); });
  $('view').addEventListener('change', e => setView(e.target.value));
  $('speed').addEventListener('change', e => { P.simSpeed = parseFloat(e.target.value); });
  P.simSpeed = parseFloat($('speed').value);

  addEventListener('keydown', e => {
    if (/^(INPUT|SELECT|BUTTON|TEXTAREA)$/.test(e.target.tagName) || e.metaKey || e.ctrlKey || e.altKey) return;
    if (e.code === 'Space') { e.preventDefault(); playBtn.click(); }
    else if (e.key === 'r' || e.key === 'R') { reset(); setRunning(true); }
  });

  // =====================================================================
  // Model viewer (Figure 2)
  // =====================================================================
  const modelBox = $('model-viewer');
  const mRenderer = makeRenderer(modelBox);
  const mScene = new THREE.Scene();
  mScene.background = new THREE.Color(tok('--bg-alt'));
  addEnvironment(mRenderer, mScene);
  mScene.add(new THREE.HemisphereLight(0xffffff, 0x9aa3ad, 0.5));
  const mSun = new THREE.DirectionalLight(0xffffff, 1.3);
  mSun.position.set(0.3, 0.8, 0.4);
  mSun.castShadow = true;
  Object.assign(mSun.shadow.camera, { left: -0.15, right: 0.15, top: 0.15, bottom: -0.15, near: 0.1, far: 2 });
  mSun.shadow.mapSize.set(1024, 1024);
  mSun.shadow.bias = -0.0002;
  mScene.add(mSun);
  const shadowFloor = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.ShadowMaterial({ opacity: 0.18 }));
  shadowFloor.rotation.x = -Math.PI / 2;
  shadowFloor.receiveShadow = true;
  mScene.add(shadowFloor);

  const showcase = buildCrazyflie(new THREE.Color(COL.a).getHex());
  showcase.props.forEach(p => { p.disc.visible = false; });
  showcase.root.position.y = 0.0216;                  // feet on the floor
  mScene.add(showcase.root);

  const mCamera = new THREE.PerspectiveCamera(35, 4 / 3, 0.01, 10);
  mCamera.position.set(0.16, 0.12, 0.2);
  const mControls = new THREE.OrbitControls(mCamera, mRenderer.domElement);
  mControls.target.set(0, 0.02, 0);
  mControls.enableDamping = true;
  mControls.autoRotate = true;
  mControls.autoRotateSpeed = 1.2;
  mControls.minDistance = 0.1;
  mControls.maxDistance = 0.6;
  mControls.maxPolarAngle = Math.PI * 0.49;
  zoomOnClick(mControls, modelBox);
  mControls.update();

  // =====================================================================
  // Sizing, visibility and main loop
  // =====================================================================
  function fit(r, cam, box) {
    const w = box.clientWidth, h = box.clientHeight;
    if (!w || !h) return;
    r.setSize(w, h, false);
    cam.aspect = w / h;
    cam.updateProjectionMatrix();
  }
  new ResizeObserver(() => { fit(renderer, camera, viewer); plotsDirty = true; }).observe(viewer);
  new ResizeObserver(() => fit(mRenderer, mCamera, modelBox)).observe(modelBox);
  new ResizeObserver(() => { plotsDirty = true; }).observe($('plot-dist'));
  fit(renderer, camera, viewer);
  fit(mRenderer, mCamera, modelBox);

  const visible = new Map([[viewer, true], [modelBox, false]]);
  const io = new IntersectionObserver(entries => entries.forEach(en => visible.set(en.target, en.isIntersecting)));
  io.observe(viewer);
  io.observe(modelBox);

  reset();
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
    while (!sim.triggered && sim.t < 30) step(H);
    for (let i = 0; i < 0.35 / H; i++) step(H);
    setRunning(false);
    mControls.autoRotate = false;
  }
  setView('overview', true);

  let last = performance.now(), acc = 0, plotClock = 0;
  function frame(now) {
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    if (running) {
      acc += dt * P.simSpeed;
      while (acc >= H) { step(H); acc -= H; }
    }
    if (visible.get(viewer)) {
      updateScene(dt);
      updateCamera(dt);
      renderer.render(scene, camera);
      updateTags();
    }
    if (visible.get(modelBox)) {
      mControls.update();
      mRenderer.render(mScene, mCamera);
    }
    updateReadout();
    plotClock += dt;
    if (plotsDirty && plotClock > 0.1) { drawPlots(); plotsDirty = false; plotClock = 0; }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
